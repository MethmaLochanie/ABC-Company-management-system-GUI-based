package Model;

import java.util.ArrayList;
import java.util.Date;

public class Booking {

    private int bookingID;
    private String cusID;
    private String hallID;
    private String bookingDateType;
    private int totalPayment;
    private int remainingPayment;
    private Date specificDate;
    private Date fromDate;
    private Date toDate;
    private String specificDay;

    public Booking(String cusID, String hallID, Date specificDate, String bookingDateType) {
        this.cusID = cusID;
        this.hallID = hallID;
        this.specificDate = specificDate;
        this.bookingDateType = bookingDateType;
    }

    public Booking(int bookingID, String cusID, String hallID, Date specificDate, String bookingDateType, int payment, int remainingPayment) {
        this.bookingID = bookingID;
        this.cusID = cusID;
        this.hallID = hallID;
        this.specificDate = specificDate;
        this.bookingDateType = bookingDateType;
        this.totalPayment = payment;
        this.remainingPayment = remainingPayment;
    }

    public Booking(String cusID, String hallID, String bookingDateType, Date fromDate, Date toDate, String specificDay) {
        this.cusID = cusID;
        this.hallID = hallID;
        this.bookingDateType = bookingDateType;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.specificDay = specificDay;
    }

    public Booking(int bookingID, String cusID, String hallID, String bookingDateType, int payment,int remainingPayment, Date fromDate, Date toDate, String specificDay) {
        this.bookingID = bookingID;
        this.cusID = cusID;
        this.hallID = hallID;
        this.bookingDateType = bookingDateType;
        this.totalPayment = payment;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.specificDay = specificDay;
        this.remainingPayment = remainingPayment;
    }

    public Booking(String cusID, String hallID, String bookingDateType, Date fromDate, Date toDate) {
        this.cusID = cusID;
        this.hallID = hallID;
        this.bookingDateType = bookingDateType;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public Booking(int bookingID, String cusID, String hallID, String bookingDateType, Date fromDate, Date toDate, int payment, int remainingPayment) {
        this.bookingID = bookingID;
        this.cusID = cusID;
        this.hallID = hallID;
        this.bookingDateType = bookingDateType;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.totalPayment = payment;
        this.remainingPayment = remainingPayment;
    }

    public Date getSpecificDate() {
        return specificDate;
    }

    public void setSpecificDate(Date specificDate) {
        this.specificDate = specificDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getSpecificDay() {
        return specificDay;
    }

    public void setSpecificDay(String specificDay) {
        this.specificDay = specificDay;
    }

    public String getBookingDateType() {
        return bookingDateType;
    }

    public void setBookingDateType(String bookingDateType) {
        this.bookingDateType = bookingDateType;
    }

    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public String getCusID() {
        return cusID;
    }

    public void setCusID(String cusID) {
        this.cusID = cusID;
    }

    public String getHallID() {
        return hallID;
    }

    public void setHallID(String hallID) {
        this.hallID = hallID;
    }

    public int getTotalPayment() {
        return totalPayment;
    }

    public void setTotalPayment(int payment) {
        this.totalPayment = payment;
    }

    public int getRemainingPayment() {
        return remainingPayment;
    }

    public void setRemainingPayment(int remainingPayment) {
        this.remainingPayment = remainingPayment;
    }

}
