/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Customer;
import Model.Hall;
import abccompany.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Methma
 */
public class HallController {
    
    private Connection con;
    
    public HallController(){
        Database db = new Database();
        con = db.getconnection();
    }
    
    public void add(Hall hall){
        
        
            String query ="INSERT INTO halls(hall_ID,hall_name, capacity, availability)VALUES(?,?,?,?)";
            
        try
              (PreparedStatement pst = con.prepareStatement(query)){
            pst.setString(1, hall.getHallID());
            pst.setString(2, hall.getHallName());
            pst.setObject(3, hall.getCapacity());
            pst.setString(4, hall.getAvailability());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Saved");
            
            
        } catch (SQLException e) {
            e.printStackTrace();;
            JOptionPane.showMessageDialog(null, "Error");

        }

 
    
    }
      public List<Hall> list() {
        List<Hall> list =new ArrayList<>();
        
        try{
        String sql= "SELECT * FROM halls";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery(); 
              
            while(rs.next()){
                Hall hall = new Hall(rs.getString("hall_ID"), rs.getString("hall_name"), rs.getInt("capacity"), rs.getString("availability"));
                list.add(hall);        
            }               
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error");       
        }      
    
        return list;        
    
      }
    
}
