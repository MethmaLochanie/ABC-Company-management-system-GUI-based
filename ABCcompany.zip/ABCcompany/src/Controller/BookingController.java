/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Booking;
import Model.Customer;
import Model.Hall;
import abccompany.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Methma
 */
public class BookingController {
    
    
    private Connection con;
    Booking booking;
    
    public BookingController(){
        Database db = new Database();
        con = db.getconnection();
    }
    
    
    public void add(Booking booking){
        
        
            String query1 ="INSERT INTO bookings(NIC, hall_ID, specific_date, specific_day, continuous_period, on_day, date_from, date_to, totalPayment, remainingPayment)VALUES(?,?,?,?,?,?,?,?,?,?)";
            
        try(PreparedStatement pst1 = con.prepareStatement(query1)){
            pst1.setString(1, booking.getCusID());
            pst1.setObject(2, booking.getHallID());
            if(booking.getBookingDateType().equalsIgnoreCase("Specific Day"))
            {
                pst1.setObject(3, "-");
                pst1.setString(4, "Yes");
                pst1.setString(5, "-");
                pst1.setString(6, booking.getSpecificDay());
                pst1.setObject(7, booking.getFromDate());
                pst1.setObject(8, booking.getToDate());
            }
            else if (booking.getBookingDateType().equalsIgnoreCase("Specific Date"))
            {
                
                pst1.setObject(3, booking.getSpecificDate());
                pst1.setString(4, "-");
                pst1.setString(5, "-");
                pst1.setString(6, "-");
                pst1.setObject(7, "-");
                pst1.setObject(8, "-");

            }
            else if (booking.getBookingDateType().equalsIgnoreCase("Continous Period"))
            {
                pst1.setObject(3, "-");
                pst1.setObject(4, "-");
                pst1.setString(5, "Yes");
                pst1.setString(6, "-");
                pst1.setObject(7, booking.getFromDate());
                pst1.setObject(8, booking.getToDate());
            }
            
            pst1.setInt(9, booking.getTotalPayment());
            pst1.setInt(10, booking.getRemainingPayment());
            pst1.executeUpdate();
            JOptionPane.showMessageDialog(null, "Booking Successfull");
            
            
        } catch (SQLException e) {
            e.printStackTrace();;
            JOptionPane.showMessageDialog(null, "Error");

        }

 
    
    }
      public List<Booking> list() {
        List<Booking> list =new ArrayList<>();
        
        try{
        String sql= "SELECT * FROM bookings";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery(); 

       String dateType = null;
              
            while(rs.next()){
                
                if(!(rs.getString("specific_date") == null))
                {

                    dateType = "Specific Date";
                    booking = new Booking(rs.getInt("bookingID"), rs.getString("NIC"), rs.getString("hall_ID"),rs.getDate("specific_date"),dateType, rs.getInt("totalPayment"),rs.getInt("remainingPayment"));
                }
                else if(!(rs.getString("specific_day") == null))
                {
                    dateType = "Specific Day";
                    booking = new Booking(rs.getInt("bookingID"), rs.getString("NIC"), rs.getString("hall_ID"),dateType, rs.getInt("totalPayment"),rs.getInt("remainingPayment"),rs.getDate("date_from"),rs.getDate("date_to"),rs.getString("on_day") );
                }
                else if(!(rs.getString("continuous_period") == null))
                {
                    dateType = "Continous Period";
                }
                booking = new Booking(rs.getInt("bookingID"), rs.getString("NIC"), rs.getString("hall_ID"),dateType,rs.getDate("date_from"),rs.getDate("date_to"), rs.getInt("totalPayment"),rs.getInt("remainingPayment"));
                list.add(booking);        
            }               
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error");       
        }      
    
        return list;        
    
      }
    
}
